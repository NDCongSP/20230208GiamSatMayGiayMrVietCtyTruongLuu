﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logger_Aplication
{
    public enum ThaoTacEnum
    {
            XoaTuDau,
            ChuyenDon,
            ChuyeKho
    }
}
