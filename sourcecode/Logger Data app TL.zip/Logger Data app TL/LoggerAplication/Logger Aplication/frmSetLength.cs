﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Logger_Aplication
{
    public partial class frmSetLength : Form
    {
        public frmSetLength()
        {
            InitializeComponent();
        }
    }
}
